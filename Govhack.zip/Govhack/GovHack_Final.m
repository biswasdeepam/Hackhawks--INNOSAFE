%% Machine Learning for govhack
%   Using Linear Regression to predict crime rate
%

%% Initialization
clear ; close all; clc

%% =========== Part 1: Loading Data =============
%  We start by first loading the dataset. 
%  The following code will load the dataset into environment 
%

% Load Training Data
fprintf('1.0 - Entering Stage 1 - Loading Data ...\n')

% Load from govhack.txt: 
% load X
data = load('train.csv');
n = size(data,2)
X = data(:, 1:(n-1)); 
y = data(:, n);

% Load from govhack2.txt: 
% load X
data_cval = load('val.csv');
n_cval = size(data_cval,2)
Xval = data(1:500, 1:(n_cval-1)); 
yval = data(1:500, n_cval);

Xtest = data(501:777, 1:(n_cval-1)); 
ytest = data(501:777, n_cval);

% m = Number of examples
m = size(X, 1);

fprintf('1.9 - Finished uploading data - Finishing stage 1.\n');
pause;

%% =========== Part 2: Regularized Linear Regression Cost =============
%
% Evaluating initial cost
fprintf('2.0 - Entering Stage 2 - Calculate initial Cost with 0 lambda ...\n')

theta = ones(n,1);
lambda = 0;
[J, grad] = linearRegCostFunction([ones(m, 1) X], y, theta, lambda);

fprintf(['Cost at theta = [1 ; 1]: %f '], J);

fprintf('2.9 - Finished calcualting cost - Finishing stage 2.\n');
pause;

%% =========== Part 3: Feature Mapping for Polynomial Regression =============
%  One solution to this is to use polynomial regression. You should now
%  complete polyFeatures to map each example into its powers
%

% feature normalise and ploy
fprintf('3.0 - Entering Stage 3 - Feature normalise and poly ...\n')

p = 2;

% Map X onto Polynomial Features and Normalize
X_poly = polyFeatures(X, p);
% X_poly = X;
[X_poly, mu, sigma] = featureNormalize(X_poly);  % Normalize
X_poly = [ones(m, 1), X_poly]; % Add Ones

% Map X_poly_test and normalize (using mu and sigma)
X_poly_test = polyFeatures(Xtest, p);
% X_poly_test = Xtest;
X_poly_test = bsxfun(@minus, X_poly_test, mu);
X_poly_test = bsxfun(@rdivide, X_poly_test, sigma);
X_poly_test = [ones(size(X_poly_test, 1), 1), X_poly_test];         % Add Ones

% Map X_poly_val and normalize (using mu and sigma)
X_poly_val = polyFeatures(Xval, p);
% X_poly_val = Xval;
X_poly_val = bsxfun(@minus, X_poly_val, mu);
X_poly_val = bsxfun(@rdivide, X_poly_val, sigma);
X_poly_val = [ones(size(X_poly_val, 1), 1), X_poly_val];           % Add Ones

fprintf('Normalized Training Example 1:\n');
fprintf('  %f  \n', X_poly(1, :));

fprintf('3.9 - Finishing Stage 3 - Feature normalise and poly ...\n')
pause;

%% =========== Part 7: Learning Curve for Polynomial Regression =============
%  Now, you will get to experiment with polynomial regression with multiple
%  values of lambda. The code below runs polynomial regression with 
%  lambda = 0. You should try running the code with different values of
%  lambda to see how the fit and learning curve change.
%

% feature normalise and ploy
fprintf('6.0 - Entering Stage 6 - lambda experiment ...\n')

lambda = 0;
[theta] = trainLinearReg(X_poly, y, lambda);

figure(2);
[error_train, error_val] = ...
    learningCurve(X_poly, y, X_poly_val, yval, lambda);
plot(1:m, error_train, 1:m, error_val);

title(sprintf('Polynomial Regression Learning Curve (lambda = %f)', lambda));
xlabel('Number of training examples')
ylabel('Error')
axis([0 9600 0 0.01])
legend('Train', 'Cross Validation')

fprintf('Polynomial Regression (lambda = %f)\n\n', lambda);
fprintf('# Training Examples\tTrain Error\tCross Validation Error\n');
for i = 1:100:m
    fprintf('  \t%d\t\t%f\t%f\n', i, error_train(i), error_val(i));
end

fprintf('6.9 - Finishing Stage 6 - training the model for theta ...\n');
fprintf('Program paused. Press enter to continue.\n');
pause;
